package com.example.uphealth;

public @interface NonNull {
}
