package com.example.uphealth;


import  androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import com.example.uphealth.adapter.CategoryAdapter;
import com.example.uphealth.adapter.DiscountedProductAdapter;
import com.example.uphealth.adapter.RecentlyViewedAdapter;
import com.example.uphealth.model.Category;
import com.example.uphealth.model.DiscountedProducts;
import com.example.uphealth.model.RecentlyViewed;
import java.util.ArrayList;
import java.util.List;

public class Categories extends AppCompatActivity {
    RecyclerView recentlyViewedRecycler;
    DiscountedProductAdapter discountedProductAdapter;
    RecentlyViewedAdapter recentlyViewedAdapter;
    List<DiscountedProducts> discountedProductsList;
    List<RecentlyViewed> recentlyViewedList;
    ImageView allCategoryImageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.heartdisease);
        recentlyViewedRecycler = findViewById(R.id.recently_itemss);
        //adding data to model
        recentlyViewedList = new ArrayList<>();
        recentlyViewedList.add(new RecentlyViewed("Watermelon", "Watermelon has high water content and also provide some fiber.", "₹ 80", "1", "KG", R.drawable.aloevera, R.drawable.aloevera));
        recentlyViewedList.add(new RecentlyViewed("Papaya", "Papaya has high water content and also provide some fiber.", "₹ 30", "1", "KG", R.drawable.capsicum, R.drawable.capsicum));
        recentlyViewedList.add(new RecentlyViewed("strawberry", "strawberry has high water content and also provide some fiber.", "₹ 85", "1", "KG", R.drawable.tumeric, R.drawable.b1));
        recentlyViewedList.add(new RecentlyViewed("Kiwi", "Kiwi has high water content and also provide some fiber.", "₹ 40", "1", "Pcs", R.drawable.lavender, R.drawable.b2));
        setRecentlyRecycler();

    }

    private void setRecentlyRecycler() {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        recentlyViewedRecycler.setLayoutManager(layoutManager);
        recentlyViewedAdapter = new RecentlyViewedAdapter(this, recentlyViewedList);
        recentlyViewedRecycler.setAdapter(recentlyViewedAdapter);
    }

}
