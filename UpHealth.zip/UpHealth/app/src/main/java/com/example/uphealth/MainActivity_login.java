package com.example.uphealth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity_login extends AppCompatActivity {
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);
        b = findViewById(R.id.toast);

        EditText emailEditText = (android.widget.EditText) findViewById(R.id.email);
        String email = emailEditText.getText().toString();

        EditText passwordEditText = (android.widget.EditText) findViewById(R.id.password);
        String password = passwordEditText.getText().toString();


    }

    public void submitButtonHandler(View view) {
        Toast.makeText(getApplicationContext(), "Login Successful!", Toast.LENGTH_SHORT).show();
        //Decide what happens when the user clicks the submit button
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
