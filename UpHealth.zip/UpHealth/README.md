# GroceryShopApp

A Grocery Shop Android App is a nice clean Online Grocery Store app UI by using Android studio, where you can show up all items by category, recently visited and most discounted. 

<img src="/app/src/main/res/drawable/GroceryShopApp1.jpeg" width="200"><img src="/app/src/main/res/drawable/GroceryShopApp7.jpg" width="200">
<img src="/app/src/main/res/drawable/GroceryShopApp2.jpg" width="200"><img src="/app/src/main/res/drawable/GroceryShopApp3.jpg" width="200">
<img src="/app/src/main/res/drawable/GroceryShopApp4.jpg" width="200"><img src="/app/src/main/res/drawable/GroceryShopApp5.jpg" width="200">
<img src="/app/src/main/res/drawable/GroceryShopApp6.jpg" width="200">

Needs a lot of improvement in terms of UI/UX, adding more features as per trend when taken to production.

<img src="/app/src/main/res/drawable/GroceryShopApp8.PNG">


[![Watch the video](https://i.imgur.com/vKb2F1B.png)](https://www.youtube.com/embed/BNhjgsp3t94?start=1)

# FAQ
How to run the project?
Install Android Studio then open the project by import Project in Android Studio.

What's the minimum framework needed?
Android 7.0 and update Android Studio.




